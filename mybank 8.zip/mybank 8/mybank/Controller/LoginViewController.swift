//
//  LoginViewController.swift
//  mybank
//
//  Created by Min Aung Hein on 8/10/19.
//  Copyright © 2019 TPS. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    var bank:Bank?

    @IBOutlet weak var userNameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBAction func login(_ sender: UIButton) {
        
//        guard truecondition else {
//            return
//        }
        
        guard let username = userNameTextField.text else {
            print("invalid user name")
            return
        }
        guard let password = passwordTextField.text else {
            print("invalid password")
            return
        }
        
        if isValidUserName(username) && isValidPassword (password){
            if let account = bank?.login( username: username, password: password)
            {
              print("login Success")
            }
            
        }
        else{
            print("Login Fail")
        }
        
    }
    
    func isValidUserName(_ userName:String) -> Bool {
        return userName.count >= 5
        
    }
    
    func isValidPassword(_ password:String) -> Bool {
        return password.count >= 5
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bank = Bank()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
