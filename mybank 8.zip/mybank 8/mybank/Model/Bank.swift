//
//  Bank.swift
//  mybank
//
//  Created by mic-student on 8/10/19.
//  Copyright © 2019 TPS. All rights reserved.
//

import Foundation

class Bank{
    
    
    static var currentAccount:Account?   //like global account
    
    let dbm:SQLiteDB
    init() {
        dbm = SQLiteDB.shared
        dbm.open()
    }
    
    
    func login(username:String, password:String) -> Account? {
        let cmd = "Select * from accounts Where username = '\(username)' AND password = '\(password)'"
        
        let rows = dbm.query(sql: cmd)
        
        if rows.count == 0 {
            return nil
        }
        
        let row = rows[0]
        let id = row["id"] as! Int
        let username = row["username"] as! String
        let account = Account(id: id, userName: username)
        Bank.currentAccount = account
        return account
    }

}
