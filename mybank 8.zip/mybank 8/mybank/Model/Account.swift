//
//  Account.swift
//  mybank
//
//  Created by mic-student on 8/10/19.
//  Copyright © 2019 TPS. All rights reserved.
//

import Foundation

class Transac {
    var tid:Int
    var amount:Double
    var frid:Int
    var toid:Int
    var opr:String  //"w","s","t"
    var dateOfTransac:Double  // number of second since 1970
    
    init(tid:Int,amount:Double,frid:Int,toid:Int,opr:String,dateOfTransac:Double){
        self.tid = tid
        self.amount = amount
        self.frid = frid
        self.toid = toid
        self.opr = opr
        self.dateOfTransac = dateOfTransac
    }
}



class Account{
    
    private var _id:Int
    var id:Int{
        return _id
    }
        
    private var _userName:String
        var username:String{
            return _userName
        
    }
    
    
    var amount:Double {
        
        return 0
    }
    
    init(id:Int,userName:String) {
        self._id = id
        self._userName = userName
        
    }
    
    func save(_ amount:Double)  {
        
    }
    func  withdraw (_ amount:Double) {
    
    }
    func transfer (_ amount:Double,_ id:Int){
        
    }
    func getTransacs(_ amount:Double){
        
    }
    
}
